"""
GAM 辅助工具模块
用于拟合广义加性模型、计算阈值交点、自助法置信区间等。
"""

import numpy as np
from sklearn.utils import resample
from scipy.stats import f
import warnings


def fit_gam(x, y, n_splines=10, lam_grid=None, progress=False):
    """
    拟合 pygam.LinearGAM 模型，返回模型对象及网格预测结果。

    Parameters
    ----------
    x : array-like, shape (n_samples, 1)
        特征值（需为 2D 列向量）。
    y : array-like, shape (n_samples,)
        目标值。
    n_splines : int, default=10
        GAM 样条基函数的数量。
    lam_grid : array-like, optional
        正则化参数 lambda 的候选网格。若为 None，则使用默认的 np.logspace(1, 7, 10)。
    progress : bool, default=False
        是否显示网格搜索进度。

    Returns
    -------
    gam : LinearGAM
        拟合好的 GAM 模型。
    XX : ndarray, shape (100, 1)
        用于绘制部分依赖图的网格点。
    pdep : ndarray, shape (100,)
        网格点对应的部分依赖值。
    confi : ndarray, shape (100, 2)
        部分依赖值的 95% 置信区间（下界，上界）。
    """
    try:
        from pygam import LinearGAM, s
    except ImportError:
        raise ImportError("请安装 pygam 库：pip install pygam")

    x = np.asarray(x).reshape(-1, 1)
    y = np.asarray(y).ravel()

    if lam_grid is None:
        lam_grid = np.logspace(1, 7, 10).reshape(-1, 1)

    gam = LinearGAM(s(0, n_splines=n_splines), fit_intercept=False).gridsearch(
        x, y, lam=lam_grid, progress=progress
    )
    XX = gam.generate_X_grid(term=0)
    pdep, confi = gam.partial_dependence(term=0, X=XX, width=0.95)
    return gam, XX, pdep.ravel(), confi


def find_thresholds(pdep, xx):
    """
    从部分依赖曲线中寻找与 y=0 的交点（线性插值）。

    Parameters
    ----------
    pdep : ndarray
        部分依赖值。
    xx : ndarray, shape (n_points, 1)
        对应的 x 坐标网格。

    Returns
    -------
    thresholds : list of float
        交点位置列表（已排序）。
    """
    xx_flat = xx.ravel()
    thresholds = []
    for i in range(len(pdep) - 1):
        y0, y1 = pdep[i], pdep[i + 1]
        if (y0 <= 0 <= y1) or (y0 >= 0 >= y1):
            x0, x1 = xx_flat[i], xx_flat[i + 1]
            if y1 != y0:
                t = -y0 / (y1 - y0)
                zero_x = x0 + t * (x1 - x0)
                thresholds.append(zero_x)
    thresholds.sort()
    return thresholds


def merge_close_thresholds(thresholds, x_min, x_max, min_distance_ratio=0.05):
    """
    合并距离过近的阈值点。

    Parameters
    ----------
    thresholds : list of float
        原始阈值列表。
    x_min : float
        特征最小值。
    x_max : float
        特征最大值。
    min_distance_ratio : float, default=0.05
        最小间距占特征值范围的比值。小于此距离的相邻阈值将被合并。

    Returns
    -------
    merged : list of float
        合并后的阈值列表。
    """
    if not thresholds:
        return []
    x_range = x_max - x_min
    min_distance = min_distance_ratio * x_range
    merged = [thresholds[0]]
    for t in thresholds[1:]:
        if t - merged[-1] > min_distance:
            merged.append(t)
    return merged


def bootstrap_gam_thresholds(x, y, original_thresholds, x_min, x_max,
                             n_bootstrap=200, ci_level=0.95,
                             n_splines=10, lam_grid=None, random_state=None):
    """
    通过自助法计算阈值点的置信区间。

    Parameters
    ----------
    x : array-like, shape (n_samples, 1)
        特征值。
    y : array-like, shape (n_samples,)
        目标值。
    original_thresholds : list of float
        原始 GAM 曲线计算出的阈值点（用于对齐数量）。
    x_min, x_max : float
        特征值的全局最小值和最大值（用于合并相近阈值）。
    n_bootstrap : int, default=200
        自助抽样次数。
    ci_level : float, default=0.95
        置信水平。
    n_splines : int, default=10
        GAM 样条数。
    lam_grid : array-like, optional
        正则化网格。
    random_state : int, optional
        随机种子。

    Returns
    -------
    results : list of dict
        每个原始阈值的置信区间信息，包含：
            threshold_index : int
            threshold_value : float
            ci_lower : float
            ci_upper : float
            bootstrap_samples : int (成功拟合的次数)
    """
    x = np.asarray(x).reshape(-1, 1)
    y = np.asarray(y).ravel()
    n_orig = len(original_thresholds)

    if n_orig == 0:
        return []

    # 存储每次 bootstrap 得到的阈值列表（按索引对齐）
    bootstrap_values = {f"thr_{i}": [] for i in range(n_orig)}

    for b in range(n_bootstrap):
        X_boot, y_boot = resample(x, y, random_state=random_state + b if random_state else None)
        try:
            gam_boot, XX_boot, pdep_boot, _ = fit_gam(
                X_boot, y_boot, n_splines=n_splines, lam_grid=lam_grid, progress=False
            )
            thr_boot = find_thresholds(pdep_boot, XX_boot)
            x_min_boot, x_max_boot = X_boot.min(), X_boot.max()
            thr_boot = merge_close_thresholds(thr_boot, x_min_boot, x_max_boot)

            # 若阈值数量与原始一致，则记录下来（否则丢弃本次 bootstrap）
            if len(thr_boot) == n_orig:
                for i, val in enumerate(thr_boot):
                    bootstrap_values[f"thr_{i}"].append(val)
        except Exception:
            # GAM 拟合失败则跳过本次迭代
            continue

    # 计算每个阈值的百分位数置信区间
    results = []
    alpha = (1 - ci_level) / 2
    lower_perc = alpha * 100
    upper_perc = (1 - alpha) * 100

    for i in range(n_orig):
        vals = bootstrap_values[f"thr_{i}"]
        if len(vals) > 0:
            ci_low = np.percentile(vals, lower_perc)
            ci_high = np.percentile(vals, upper_perc)
        else:
            ci_low = ci_high = np.nan
        results.append({
            'threshold_index': i,
            'threshold_value': original_thresholds[i],
            'ci_lower': ci_low,
            'ci_upper': ci_high,
            'bootstrap_samples': len(vals)
        })
    return results


def compute_gam_r2_pvalue(gam, x, y):
    """
    计算 GAM 模型的 R² 和 p 值（基于 F 检验）。

    Parameters
    ----------
    gam : LinearGAM
        已拟合的 GAM 模型。
    x : array-like, shape (n_samples, 1)
        特征值。
    y : array-like, shape (n_samples,)
        观测值。

    Returns
    -------
    r2 : float
        决定系数。
    p_value : float
        F 检验的 p 值。
    """
    x = np.asarray(x).reshape(-1, 1)
    y = np.asarray(y).ravel()
    y_pred = gam.predict(x).ravel()

    rss = np.sum((y - y_pred) ** 2)
    tss = np.sum((y - np.mean(y)) ** 2)
    r2 = 1 - (rss / tss) if tss != 0 else np.nan

    n = len(y)
    edof = gam.statistics_['edof']   # 有效自由度
    mss = tss - rss
    df_model = edof
    df_resid = n - df_model
    if df_resid > 0 and mss > 0 and rss > 0:
        F = (mss / df_model) / (rss / df_resid)
        p_value = f.sf(F, df_model, df_resid)
    else:
        p_value = np.nan
    return r2, p_value