"""
使用 GeoShapley 计算特征偏依赖图（Partial Dependence Plots）
需要安装 geoshapley 库
"""

import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.cluster import KMeans
from geoshapley import GeoShapleyExplainer
import matplotlib.pyplot as plt
import os

from config import DATA_DIR, FILE_NAMES, FEATURE_COLS, TARGET_COL, LON_LAT_COLS, RANDOM_STATE

# 对于 GeoShapley，特征必须包含经纬度
GEO_FEATURES = FEATURE_COLS + LON_LAT_COLS   # 原 FEATURE_COLS 中可能不含经纬度，需追加
GEO_FEATURES = list(set(GEO_FEATURES))       # 去重，保持顺序不重要

# 目标变量可根据需要手动修改（本例使用 LCE）
TARGET = 'LCE'   # 或 'LCS'


def main():
    # 1. 加载数据（以某一年为例，例如 2022）
    year = 2022
    file_path = os.path.join(DATA_DIR, FILE_NAMES[year])
    data = pd.read_csv(file_path, encoding='gbk')
    print("数据预览:\n", data.head())

    X = data[GEO_FEATURES]
    y = data[TARGET]

    # 2. 训练 LightGBM 模型
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=RANDOM_STATE)
    params = {
        'learning_rate': 0.05,
        'max_depth': -1,
        'n_estimators': 500,
        'num_leaves': 63,
        'subsample': 0.8,
        'random_state': RANDOM_STATE,
        'verbosity': -1
    }
    model = lgb.LGBMRegressor(**params)
    model.fit(X_train, y_train)
    print(f"模型 R² (测试集): {r2_score(y_test, model.predict(X_test)):.4f}")

    # 3. 准备 GeoShapley 解释器
    def predict_function(X_array):
        if isinstance(X_array, np.ndarray):
            X_df = pd.DataFrame(X_array, columns=GEO_FEATURES)
        else:
            X_df = X_array
        return model.predict(X_df)

    # 背景数据集：使用 KMeans 聚类中心
    kmeans = KMeans(n_clusters=100, random_state=RANDOM_STATE)
    kmeans.fit(X_train)
    background = pd.DataFrame(kmeans.cluster_centers_, columns=GEO_FEATURES)

    explainer = GeoShapleyExplainer(
        predict_f=predict_function,
        background=background,
        g=2,                     # 经纬度作为地理特征
        exact=False,
        n_sampled_coalitions=1000
    )

    # 4. 计算部分样本的 GeoShapley 值并绘制偏依赖图
    X_sample = X.sample(n=50, random_state=RANDOM_STATE)   # 可增加样本数，但计算量会增大
    print(f"正在计算 {len(X_sample)} 个样本的 GeoShapley 值...")
    results = explainer.explain(X_sample, n_jobs=6)

    # 绘制偏依赖图（GAM 平滑曲线）
    results.partial_dependence_plots(
        figsize=(9, 6),
        max_cols=4,
        gam_curve=True,
        s=10,
        dpi=100
    )
    # 可选：保存图片
    # plt.savefig("GeoShapley_PDP.png", dpi=100)
    plt.show()


if __name__ == "__main__":
    main()