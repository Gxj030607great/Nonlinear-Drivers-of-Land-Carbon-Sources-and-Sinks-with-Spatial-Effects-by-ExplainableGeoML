"""
SHAP 交互值分析：绘制两个变量的交互散点图，并按第三个变量（或同一变量）分组拟合 GAM 曲线，
计算两条拟合线的交点（带置信区间填充）。
"""

import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import shap
from pygam import LinearGAM, s
from scipy.interpolate import interp1d
import os

from config import DATA_DIR, FILE_NAMES, RANDOM_STATE

# 本脚本独立配置特征与目标（可根据需要修改）
FEATURES = ['pre', 'srad', 'contag', 'tmp', 'HAI', 'LPI', 'PD', 'RD', 'GDP', 'NDVI', 'pop', 'longitude', 'latitude']
TARGET = 'LCS'   # 或 'LCE'
YEAR = 2022
VAR1 = "tmp"     # x 轴变量
VAR2 = "srad"    # 分组变量（颜色映射，以及分组阈值依据）
THRESHOLD_TYPE = "mean"   # 分组阈值计算方式: "mean", "median", 或直接数值

# 模型参数（与主实验保持一致）
LGB_PARAMS = {
    'learning_rate': 0.1,
    'max_depth': 7,
    'n_estimators': 500,
    'num_leaves': 63,
    'random_state': RANDOM_STATE,
    'verbosity': -1
}
# 若使用另一组参数，可取消注释：
# LGB_PARAMS = {
#     'learning_rate': 0.05,
#     'max_depth': -1,
#     'n_estimators': 500,
#     'num_leaves': 63,
#     'subsample': 0.8,
#     'random_state': RANDOM_STATE,
#     'verbosity': -1
# }

# 绘图设置
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10


def load_data(year, target):
    file_path = os.path.join(DATA_DIR, FILE_NAMES[year])
    data = pd.read_csv(file_path, encoding='gbk')
    X = data[FEATURES]
    y = data[target]
    return X, y, data


def train_model(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=RANDOM_STATE)
    model = lgb.LGBMRegressor(**LGB_PARAMS)
    model.fit(X_train, y_train)
    print(f"模型 R² (测试集): {r2_score(y_test, model.predict(X_test)):.4f}")
    return model, X_test


def compute_shap_interaction(model, X_sample, var1, var2, features):
    explainer = shap.TreeExplainer(model)
    shap_interaction_values = explainer.shap_interaction_values(X_sample)
    idx1 = features.index(var1)
    idx2 = features.index(var2)
    interaction = shap_interaction_values[:, idx1, idx2]
    return interaction


def fit_gam_group(x_vals, y_vals, n_splines=10):
    """拟合 GAM 并返回网格预测值和置信区间"""
    x = x_vals.reshape(-1, 1)
    gam = LinearGAM(s(0, n_splines=n_splines)).fit(x, y_vals)
    x_grid = np.linspace(x.min(), x.max(), 100).reshape(-1, 1)
    y_pred = gam.predict(x_grid)
    conf = gam.confidence_intervals(x_grid, width=0.95)
    return x_grid.ravel(), y_pred, conf


def find_intersections(x1, y1, x2, y2):
    """计算两条曲线 (x1,y1) 和 (x2,y2) 的所有交点（线性插值）"""
    # 确定共同 x 范围
    x_min = max(x1.min(), x2.min())
    x_max = min(x1.max(), x2.max())
    if x_min >= x_max:
        return []
    # 插值到公共网格
    x_common = np.linspace(x_min, x_max, 500)
    interp1 = interp1d(x1, y1, kind='linear', fill_value='extrapolate')
    interp2 = interp1d(x2, y2, kind='linear', fill_value='extrapolate')
    y1_common = interp1(x_common)
    y2_common = interp2(x_common)

    diff = y1_common - y2_common
    sign_diff = np.sign(diff)
    change_idx = np.where(np.diff(sign_diff) != 0)[0]
    intersections = []
    for idx in change_idx:
        x_left, x_right = x_common[idx], x_common[idx+1]
        y_left, y_right = diff[idx], diff[idx+1]
        x_inter = x_left - y_left * (x_right - x_left) / (y_right - y_left)
        intersections.append(x_inter)
    # 去重（距离小于0.01视为相同）
    uniq = []
    for x in intersections:
        if not uniq or np.min(np.abs(np.array(uniq) - x)) > 0.01:
            uniq.append(x)
    return uniq


def main():
    # 加载数据
    X, y, data_raw = load_data(YEAR, TARGET)
    model, X_test = train_model(X, y)

    # 可选：采样测试集以加速
    sample_size = 7000
    if len(X_test) > sample_size:
        np.random.seed(RANDOM_STATE)
        sample_idx = np.random.choice(len(X_test), sample_size, replace=False)
        X_sample = X_test.iloc[sample_idx]
    else:
        X_sample = X_test
    print(f"分析样本数: {len(X_sample)}")

    # 计算 SHAP 交互值
    shap_interaction = compute_shap_interaction(model, X_sample, VAR1, VAR2, FEATURES)

    # 确定分组阈值
    if THRESHOLD_TYPE == "mean":
        threshold = data_raw[VAR2].mean()
    elif THRESHOLD_TYPE == "median":
        threshold = data_raw[VAR2].median()
    else:
        threshold = float(THRESHOLD_TYPE)
    print(f"分组阈值 ({VAR2}): {threshold:.4f}")

    mask_high = X_sample[VAR2] >= threshold
    mask_low = X_sample[VAR2] < threshold

    # 绘制散点图
    plt.figure(figsize=(5, 3.5), dpi=150)
    sc = plt.scatter(X_sample[VAR1], shap_interaction,
                     s=3, c=X_sample[VAR2], cmap='jet', alpha=1)
    cbar = plt.colorbar(sc, aspect=40, shrink=0.8)
    cbar.set_label(VAR2, fontsize=10)
    plt.axhline(y=0, color='black', linestyle='-.', linewidth=0.8)

    # 分组拟合 GAM 并绘制曲线和置信区间
    x_high, y_high, conf_high = None, None, None
    x_low, y_low, conf_low = None, None, None

    # 高值组
    X_high = X_sample.loc[mask_high, VAR1].values
    y_high_vals = shap_interaction[mask_high]
    if len(X_high) >= 10:
        try:
            x_high, y_high, conf_high = fit_gam_group(X_high, y_high_vals)
            plt.fill_between(x_high, conf_high[:, 0], conf_high[:, 1],
                             color='red', alpha=0.2)
            plt.plot(x_high, y_high, color='red', linewidth=2,
                     label=f'{VAR2} ≥ {threshold:.2f}')
        except Exception as e:
            print(f"高值组 GAM 拟合失败: {e}")

    # 低值组
    X_low = X_sample.loc[mask_low, VAR1].values
    y_low_vals = shap_interaction[mask_low]
    if len(X_low) >= 10:
        try:
            x_low, y_low, conf_low = fit_gam_group(X_low, y_low_vals)
            plt.fill_between(x_low, conf_low[:, 0], conf_low[:, 1],
                             color='blue', alpha=0.2)
            plt.plot(x_low, y_low, color='blue', linewidth=2,
                     label=f'{VAR2} < {threshold:.2f}')
        except Exception as e:
            print(f"低值组 GAM 拟合失败: {e}")

    # 计算并标注交点
    if x_high is not None and x_low is not None:
        intersections = find_intersections(x_high, y_high, x_low, y_low)
        if intersections:
            print(f"找到交点: {[f'{x:.4f}' for x in intersections]}")
            y_min, y_max = plt.gca().get_ylim()
            text_y = y_min + 0.02 * (y_max - y_min)
            for x_inter in intersections:
                # 取高组曲线在该点的值
                interp_high = interp1d(x_high, y_high, kind='linear', fill_value='extrapolate')
                y_inter = interp_high(x_inter)
                plt.axvline(x=x_inter, color='gray', linestyle='--', linewidth=1, alpha=0.7)
                plt.plot(x_inter, y_inter, 'ko', markersize=4)
                plt.text(x_inter, text_y, f'x={x_inter:.2f}', fontsize=8, ha='center', va='bottom')
        else:
            print("未检测到交点")
    else:
        print("至少一组拟合失败，无法计算交点")

    plt.legend(loc='best', fontsize=8)
    plt.xlabel(VAR1, fontsize=10)
    plt.ylabel(f'SHAP interaction\n({VAR1} × {VAR2})', fontsize=10)

    ax = plt.gca()
    ax.tick_params(axis='both', labelsize=8)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    plt.tight_layout()
    out_file = f"SHAP_interaction_{VAR1}_{VAR2}_{YEAR}.png"
    plt.savefig(out_file, dpi=300, bbox_inches='tight')
    print(f"图片已保存: {out_file}")
    plt.show()


if __name__ == "__main__":
    main()