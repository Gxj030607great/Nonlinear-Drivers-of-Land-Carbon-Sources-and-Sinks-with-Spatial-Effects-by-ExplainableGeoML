"""
基于空间分组交叉验证的多模型评估
使用 KMeans 空间聚类划分块，GroupKFold 验证
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import GroupKFold, GridSearchCV
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from scipy import stats
import lightgbm as lgb
import xgboost as xgb
import warnings
import os

from config import (
    DATA_DIR, FILE_NAMES, FEATURE_COLS, TARGET_COL,
    LON_LAT_COLS, K_BLOCKS, N_SPLITS, RANDOM_STATE, PARAM_GRIDS
)

warnings.filterwarnings('ignore')


def load_all_data(data_dir, file_names):
    """读取多年份 CSV 并添加 year 列"""
    df_list = []
    for year, fname in file_names.items():
        path = os.path.join(data_dir, fname)
        df_year = pd.read_csv(path, encoding='gbk')
        df_year['year'] = year
        df_list.append(df_year)
    df_all = pd.concat(df_list, ignore_index=True)
    return df_all


def evaluate_model_space_cv(model, X, y, groups, cv):
    """使用分组交叉验证返回每折的 RMSE 和 R² 列表"""
    rmse_list, r2_list = [], []
    for train_idx, val_idx in cv.split(X, y, groups):
        X_tr, X_val = X[train_idx], X[val_idx]
        y_tr, y_val = y[train_idx], y[val_idx]
        # 克隆模型避免参数污染
        if hasattr(model, 'get_params'):
            model_clone = model.__class__(**model.get_params())
            model_clone.fit(X_tr, y_tr)
        else:
            # 对于 LinearRegression 等无 get_params 的简单处理
            model_clone = model.__class__()
            model_clone.fit(X_tr, y_tr)
        y_pred = model_clone.predict(X_val)
        rmse_list.append(np.sqrt(mean_squared_error(y_val, y_pred)))
        r2_list.append(r2_score(y_val, y_pred))
    return rmse_list, r2_list


def main():
    # 1. 读取数据
    print("加载数据...")
    df_all = load_all_data(DATA_DIR, FILE_NAMES)
    print(f"总数据量: {df_all.shape}")
    print("各年份样本数:\n", df_all['year'].value_counts().sort_index())

    # 2. 划分训练集 (2002,2009,2016) 和测试集 (2022)
    train_years = [2002, 2009, 2016]
    test_year = 2022
    df_train = df_all[df_all['year'].isin(train_years)].copy()
    df_test = df_all[df_all['year'] == test_year].copy()
    print(f"\n训练集: {len(df_train)}, 测试集: {len(df_test)}")

    X_train = df_train[FEATURE_COLS].values
    y_train = df_train[TARGET_COL].values
    X_test = df_test[FEATURE_COLS].values
    y_test = df_test[TARGET_COL].values

    # 3. 构建空间块（KMeans 聚类）
    coords = df_train[LON_LAT_COLS].values
    kmeans = KMeans(n_clusters=K_BLOCKS, random_state=RANDOM_STATE, n_init=10)
    df_train['block_id'] = kmeans.fit_predict(coords)
    block_counts = df_train['block_id'].value_counts()
    print(f"\n空间块数: {len(block_counts)}")
    print(f"每块样本量: 平均={block_counts.mean():.1f}, 最小={block_counts.min()}, 最大={block_counts.max()}")

    group_kfold = GroupKFold(n_splits=N_SPLITS)
    groups = df_train['block_id']

    # 4. 定义模型
    models = {
        'LinearRegression': LinearRegression(),
        'DecisionTree': DecisionTreeRegressor(random_state=RANDOM_STATE),
        'KNN': KNeighborsRegressor(),
        'RandomForest': RandomForestRegressor(random_state=RANDOM_STATE),
        'XGBoost': xgb.XGBRegressor(random_state=RANDOM_STATE, verbosity=0),
        'LightGBM': lgb.LGBMRegressor(random_state=RANDOM_STATE, verbose=-1)
    }

    results = []
    print(f"\n{'='*50}\n开始模型评估\n{'='*50}")

    for model_name, model in models.items():
        print(f"\n--- 模型: {model_name} ---")
        if model_name in PARAM_GRIDS:
            print("网格搜索最优参数...")
            gs = GridSearchCV(
                estimator=model,
                param_grid=PARAM_GRIDS[model_name],
                cv=group_kfold,
                scoring='neg_root_mean_squared_error',
                n_jobs=-1,
                verbose=1
            )
            gs.fit(X_train, y_train, groups=groups)
            best_model = gs.best_estimator_
            print(f"最佳参数: {gs.best_params_}")
            model = best_model
        else:
            model.fit(X_train, y_train)

        # 空间交叉验证
        rmse_cv, r2_cv = evaluate_model_space_cv(model, X_train, y_train, groups, group_kfold)
        mean_rmse_cv, std_rmse_cv = np.mean(rmse_cv), np.std(rmse_cv, ddof=1)
        mean_r2_cv, std_r2_cv = np.mean(r2_cv), np.std(r2_cv, ddof=1)

        # 测试集评估
        y_pred_test = model.predict(X_test)
        rmse_test = np.sqrt(mean_squared_error(y_test, y_pred_test))
        r2_test = r2_score(y_test, y_pred_test)
        mae_test = mean_absolute_error(y_test, y_pred_test)

        results.append({
            'model': model_name,
            'cv_rmse_mean': mean_rmse_cv,
            'cv_rmse_std': std_rmse_cv,
            'cv_r2_mean': mean_r2_cv,
            'cv_r2_std': std_r2_cv,
            'test_rmse': rmse_test,
            'test_r2': r2_test,
            'test_mae': mae_test,
            'rmse_cv_list': rmse_cv,
            'r2_cv_list': r2_cv
        })

        print(f"空间CV RMSE: {mean_rmse_cv:.4f} (±{std_rmse_cv:.4f})")
        print(f"空间CV R² : {mean_r2_cv:.4f} (±{std_r2_cv:.4f})")
        print(f"测试集 RMSE: {rmse_test:.4f}, R²: {r2_test:.4f}")

    # 结果汇总
    df_results = pd.DataFrame(results)
    print("\n\n=== 所有模型评估结果 ===")
    print(df_results[['model', 'cv_rmse_mean', 'cv_rmse_std', 'cv_r2_mean', 'cv_r2_std', 'test_rmse', 'test_r2']].to_string(index=False))

    # 统计检验：空间CV RMSE 与 测试集 RMSE 是否有显著差异
    print("\n\n=== 统计显著性检验（测试集 RMSE vs 空间CV RMSE）===")
    stats_results = []
    for res in results:
        rmse_list = res['rmse_cv_list']
        test_rmse = res['test_rmse']
        t_stat, p_t = stats.ttest_1samp(rmse_list, test_rmse)
        w_stat, p_w = stats.wilcoxon([x - test_rmse for x in rmse_list])
        stats_results.append({
            'model': res['model'],
            't_stat': t_stat,
            'p_t': p_t,
            'W': w_stat,
            'p_w': p_w
        })
        print(f"{res['model']}: t={t_stat:.4f}, p_t={p_t:.4f} | W={w_stat:.0f}, p_w={p_w:.4f}")

    df_stats = pd.DataFrame(stats_results)
    print("\n=== 统计检验汇总 ===")
    print(df_stats.to_string(index=False))


if __name__ == "__main__":
    main()