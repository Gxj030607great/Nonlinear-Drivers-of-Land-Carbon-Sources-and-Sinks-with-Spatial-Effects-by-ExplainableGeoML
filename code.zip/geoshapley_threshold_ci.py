"""
计算 GeoShapley 偏依赖图中阈值点及其 bootstrap 置信区间
"""

import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.cluster import KMeans
from geoshapley import GeoShapleyExplainer
import matplotlib.pyplot as plt
import os

from config import DATA_DIR, FILE_NAMES, FEATURE_COLS, TARGET_COL, LON_LAT_COLS, RANDOM_STATE

GEO_FEATURES = FEATURE_COLS + LON_LAT_COLS
GEO_FEATURES = list(set(GEO_FEATURES))
TARGET = 'LCE'   # 修改为 LCS 或其他


def main():
    year = 2002   # 可更改
    file_path = os.path.join(DATA_DIR, FILE_NAMES[year])
    data = pd.read_csv(file_path, encoding='gbk')
    print("数据预览:\n", data.head())

    # 注意：这里使用与原示例不同的特征集（包含 tmp 等），可按需调整
    # 为保持一致性，直接使用 GEO_FEATURES（不含 tmp）
    X = data[GEO_FEATURES]
    y = data[TARGET]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=RANDOM_STATE)
    params = {
        'learning_rate': 0.1,
        'max_depth': 7,
        'n_estimators': 500,
        'num_leaves': 63,
        'random_state': RANDOM_STATE,
        'verbosity': -1
    }
    model = lgb.LGBMRegressor(**params)
    model.fit(X_train, y_train)
    print(f"模型 R²: {r2_score(y_test, model.predict(X_test)):.4f}")

    def predict_function(X_array):
        if isinstance(X_array, np.ndarray):
            X_df = pd.DataFrame(X_array, columns=GEO_FEATURES)
        else:
            X_df = X_array
        return model.predict(X_df)

    kmeans = KMeans(n_clusters=100, random_state=RANDOM_STATE)
    kmeans.fit(X_train)
    background = pd.DataFrame(kmeans.cluster_centers_, columns=GEO_FEATURES)

    explainer = GeoShapleyExplainer(
        predict_f=predict_function,
        background=background,
        g=2,
        exact=False,
        n_sampled_coalitions=1000
    )

    X_sample = X.sample(n=5000, random_state=RANDOM_STATE)
    print(f"计算 {len(X_sample)} 个样本的 GeoShapley 值...")
    results = explainer.explain(X_sample, n_jobs=6)

    # 绘制偏依赖图，同时计算阈值点及 bootstrap 置信区间
    thresholds_df = results.partial_dependence_plots(
        figsize=(9, 6),
        max_cols=4,
        gam_curve=True,
        s=10,
        dpi=100,
        bootstrap_n=200,      # bootstrap 次数
        ci_level=0.95
    )

    # 输出阈值点信息
    if thresholds_df is not None:
        print("\n" + "="*60)
        print("各特征阈值点及其95%置信区间")
        print("="*60)
        for feature in thresholds_df['feature'].unique():
            print(f"\n特征: {feature}")
            feature_rows = thresholds_df[thresholds_df['feature'] == feature]
            for _, row in feature_rows.iterrows():
                idx = row['threshold_index']
                thresh = row['threshold_value']
                lower = row['ci_lower']
                upper = row['ci_upper']
                n_boot = row['bootstrap_samples']
                if not np.isnan(lower):
                    print(f"  阈值 {idx}: {thresh:.4f}  [95% CI: ({lower:.4f}, {upper:.4f})] (基于 {n_boot} 次bootstrap)")
                else:
                    print(f"  阈值 {idx}: {thresh:.4f}  置信区间无法计算 (有效bootstrap样本数: {n_boot})")
        print("="*60)
    else:
        print("未检测到阈值点。")

    # 保存图片
    plt.savefig(f"GeoShapley_PDP_with_CI_{year}.png", dpi=100)
    plt.show()


if __name__ == "__main__":
    main()