# config.py
# 全局配置文件，修改此处可调整所有分析

# 数据路径（相对于当前脚本的路径，或使用绝对路径）
DATA_DIR = "../data/"   # 存放 CSV 文件的目录
FILE_NAMES = {
    2002: "2002GWRF.csv",
    2009: "2009GWRF.csv",
    2016: "2016GWRF.csv",
    2022: "2022GWRF.csv"
}

# 特征与目标
FEATURE_COLS = ['RD', 'PD', 'LPI', 'contag', 'pre', 'pop', 'NDVI', 'HAI', 'GDP', 'DEM', 'srad']
TARGET_COL = 'LCE'   # 或 'LCS'

# 地理坐标列（用于空间聚类）
LON_LAT_COLS = ['longitude', 'latitude']

# 空间块数
K_BLOCKS = 200

# 分组交叉验证折数
N_SPLITS = 5

# 随机种子
RANDOM_STATE = 42

# 模型参数网格（可根据需要调整）
PARAM_GRIDS = {
    'DecisionTree': {
        'max_depth': [None, 5, 10],
        'min_samples_split': [2, 5, 10]
    },
    'RandomForest': {
        'n_estimators': [100, 200],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5]
    },
    'XGBoost': {
        'n_estimators': [100, 200],
        'learning_rate': [0.01, 0.05, 0.1],
        'max_depth': [3, 5, 7]
    },
    'LightGBM': {
        'n_estimators': [100, 200, 300],
        'learning_rate': [0.01, 0.05, 0.1],
        'max_depth': [-1, 5, 7],
        'num_leaves': [31, 63]
    }
}